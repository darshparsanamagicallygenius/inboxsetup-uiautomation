# error_validation.py
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC

def check_error_message(driver, xpath):
    """
    Function to check for error message using XPath.
    Returns a tuple (status, message).
    - status: True if no error message, False if error message found
    - message: Error message text or an appropriate message if no error
    """
    try:
        # Wait for the error message element to be present
        error_message_element = WebDriverWait(driver, 5).until(
            EC.presence_of_element_located((By.XPATH, xpath))
        )
        # Extract the error message text
        error_message = error_message_element.text
        return False, error_message  # Login failed, return the error message
    except Exception as e:
        # If no error message element is found, return success with a message
        return True, "No error message found"  # Login likely successful
