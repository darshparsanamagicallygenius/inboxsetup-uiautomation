import time
from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.chrome.service import Service
from selenium.webdriver.chrome.options import Options
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from webdriver_manager.chrome import ChromeDriverManager
from xpaths import XPATHS
import logging
from error_validation import check_error_message

# Setup logging
# logging.basicConfig(level=logging.DEBUG)

class SmartLeadAutomation:
    def __init__(self, login_email, login_password, auth_email, auth_password):
        # Initialize instance variables
        self.login_email = login_email
        self.login_password = login_password
        self.auth_email = auth_email
        self.auth_password = auth_password
        
        # Use ChromeDriverManager to explicitly specify the version
        driver_path = ChromeDriverManager().install()  # This will automatically fetch the correct version for your browser

        options = Options()
        # options.add_argument('--headless')  # Uncomment if you want headless mode
        options.add_argument('--no-sandbox')
        options.add_argument('--disable-dev-shm-usage')

        # Set up the service with the installed ChromeDriver
        service = Service(driver_path)
        self.driver = webdriver.Chrome(service=service, options=options)

        self.wait = WebDriverWait(self.driver, 30) 

    def wait_for_element(self, xpath, clickable=False):
        """Wait for an element to appear or be clickable."""
        condition = EC.element_to_be_clickable if clickable else EC.presence_of_element_located
        return self.wait.until(condition((By.XPATH, xpath)))

    def wait_for_page_load(self):
        """Waits for the page to be completely loaded."""
        WebDriverWait(self.driver, 30).until(
            lambda driver: self.driver.execute_script("return document.readyState") == "complete"
        )

    def click_element(self, xpath):
        """Click on an element and ensure page load."""
        element = self.wait_for_element(xpath, clickable=True)
        try:
            element.click()
        except Exception as e:
            logging.error(f"Failed to click on {xpath}: {str(e)}")
            self.driver.execute_script("arguments[0].click();", element)
        self.wait_for_page_load()

    def send_keys_to_element(self, xpath, keys):
        """Send keys to an input element."""
        input_element = self.wait_for_element(xpath)
        input_element.send_keys(keys)

    def handle_login(self):
        """Handle the login process."""
        try:
            self.driver.get("https://app.smartlead.ai/login")
            logging.info("Navigating to login page...")
            self.wait_for_page_load()
            self.send_keys_to_element(XPATHS["email_input"], self.login_email)
            self.send_keys_to_element(XPATHS["password_input"], self.login_password)
            self.click_element(XPATHS["login_button"])
            
            status, message = check_error_message(self.driver, "//*[@id='q-app']/div/div/main/section/div/div")
            return status, message
        except Exception as e:
            logging.error(f"Login failed: {str(e)}")
            return False, f"Login failed: {str(e)}"

    def perform_action_sequence(self, actions):
        """Perform a sequence of actions."""
        for action in actions:
            try:
                action()
            except Exception as e:
                logging.error(f"Action failed: {str(e)}")
                raise Exception(f"Action failed: {str(e)}")

    def check_error_message(self):
        """Check for any error message on the page."""
        try:
            # Find all divs or elements that might contain error messages
            error_elements = WebDriverWait(self.driver, 10).until(
                EC.presence_of_all_elements_located((By.XPATH, "//div[contains(@class, 'error') or contains(@class, 'alert')]"))
            )
            
            # If error elements exist, extract their text
            if error_elements:
                error_texts = [element.text for element in error_elements if element.text.strip() != ""]
                if error_texts:
                    return " | ".join(error_texts)  # Join multiple error texts if found
                else:
                    return "No error message found."
            else:
                return "No error message found or another error occurred."
        
        except Exception as e:
            logging.info(f"Error while checking for error messages: {str(e)}")
            return "No error message found or another error occurred."

    def close_notification(self):
        """Close any notifications that may pop up."""
        try:
            self.click_element("//img[contains(@class, 'gleap-notification-item-news-image')]")
        except Exception:
            logging.info("No notification found or could not close.")

    def main_process(self):
        """Perform the main sequence of actions."""
        actions = [
            lambda: self.click_element(XPATHS["email_accounts_button"]),
            lambda: self.click_element(XPATHS["add_account_button"]),
            lambda: self.wait_for_page_load(),
            lambda: time.sleep(3),
            lambda: self.driver.save_screenshot("before_oauth_one_click_setup_button.png"),
            lambda: self.click_element(XPATHS["oauth_one_click_setup_button"]),
            lambda: self.wait_for_page_load(),
            lambda: time.sleep(3),
            lambda: self.driver.save_screenshot("before_connect_account_button.png"),
            lambda: self.click_element(XPATHS["connect_account_button"]),
            lambda: self.wait_for_page_load(),
            lambda: time.sleep(3),
            lambda: self.driver.save_screenshot("before_email_or_phone_input.png"),
            lambda: self.send_keys_to_element(XPATHS["email_or_phone_input"], str(self.auth_email)),
            lambda: self.wait_for_page_load(),
            lambda: time.sleep(3),
            lambda: self.driver.save_screenshot("before_next_button.png"),
            # lambda: self.click_element("//button[span[text()='Next']]"),
            lambda: self.driver.find_element(By.ID, "identifierNext").click(),
            lambda: self.wait_for_page_load(),
            lambda: time.sleep(3),
            lambda: self.driver.save_screenshot("before_password_input_field.png"),
            
            # lambda: self.driver.find_element(By.ID, "identifierNext").click(),
            lambda: self.enter_password_if_present(),
            lambda: self.wait_for_page_load(),
            lambda: time.sleep(3),
            lambda: self.driver.save_screenshot("before_check_next_button.png"),

            # lambda: self.click_element(XPATHS["next_button_after_password"]),
            lambda: self.click_next_button_if_present(),
            lambda: self.wait_for_page_load(),
            lambda: time.sleep(3),
            lambda: self.driver.save_screenshot("before_continue_button.png"),

            lambda: self.click_element(XPATHS["continue_button"]),
            lambda: self.wait_for_page_load(),
            lambda: time.sleep(3),
            lambda: self.click_element(XPATHS["allow_button"]),
            lambda: time.sleep(3)
        ]
        self.perform_action_sequence(actions)

    def enter_password_if_present(self):
        try:
            driver1 = self.driver
            driver2 = self.driver
            # Check if there's an input element inside the div
            input_element = self.driver.find_element(By.XPATH, ".//input[@type='password']")
            # next_button = WebDriverWait(self.driver, 10).until(
            #         EC.element_to_be_clickable((By.ID, "passwordNext"))
            #     )
            # If found, send the password to the input field
            if input_element:
                input_element.send_keys(str(self.auth_password))
                # next_button.click()  # Click the button
            else:
                print("Password input field not found.")

            # try:
            #     next_button = WebDriverWait(self.driver, 10).until(
            #         EC.element_to_be_clickable((By.ID, "passwordNext"))
            #     )

            #     # Step 4: Click the "Next" button
            #     if next_button:
            #         print("Clicking the 'Next' button.")
            #         self.driver.save_screenshot("before_click_on_next_button.png")
            #         next_button.click()  # Click the button
            #         print("Clicked the 'Next' button successfully.")
            #         self.driver.save_screenshot("after_click_on_next_button.png"),
            #     else:
            #         print("'Next' button not found or is not clickable.")
            # except Exception as e:
            #     print(f"Error finding password input: {e}")

                
        except Exception as e:
            print(f"Error finding password input: {e}")

    # Method to check for the 'Next' button and click it
    def click_next_button_if_present(self):
        """Enter the password and check for a button of type 'button' inside any div to click it."""
        try:
            
            # Step 3: Find the "Next" button (with text 'Next') inside any div
            # XPath checks for a button with type 'button' and containing a span with the text 'Next'
            try:
                next_button = self.driver.find_element(By.XPATH, "//button[@type='button']//span[text()='Next']")
                if next_button:
                    # We need to click the parent button element, not the span itself
                    button_element = next_button.find_element(By.XPATH, './..')  # Go up one level to the <button> element
            except:
                next_button = self.driver.find_element(By.ID, "passwordNext")
            
            # Step 4: Click the "Next" button if it is found
            next_button.click()  # Click the button
            
        except Exception as e:
            # Capture any other errors and log them
            page_source = self.driver.page_source

    def close_driver(self):
        """Close the WebDriver."""
        self.driver.quit()

# if __name__ == "__main__":
#     # Pass parameters dynamically when creating an instance of the class
#     automation = SmartLeadAutomation(
#         login_email="darsh@magicallygenius.ai",
#         login_password="Darshkinghou@123@",
#         auth_email="frank@theyouratlanticasphalt.com",
#         auth_password="z2Y@8c2o@p2Y"
#     )
#     # Handle login and capture any error message
#     status, message = automation.handle_login()
#     if not status:
#         print("Login failed:")
#         print({"error": message})
    
#     # Proceed with the main automation process
#     try:
#         automation.main_process()
#         print("Process completed successfully.")
#     except Exception as e:
#         print(f"Process failed: {str(e)}")
#     finally:
#         automation.close_driver()
