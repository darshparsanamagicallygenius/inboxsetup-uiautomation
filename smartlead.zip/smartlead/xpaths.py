# Define all your XPath expressions in a dictionary
XPATHS = {
    "email_input": "//input[@name='email']",
    "password_input": "//input[@name='password']",
    "login_button": "//button[span/span[text()='Login']]",
    "email_accounts_button": "//a[.//p[text()='Email Accounts']]",
    "add_account_button": "//button[span/span[text()='Add Account(s)']]",
    "oauth_one_click_setup_button": "//div[contains(@class, 'add-account-card-big')]//p[text()='One Click Setup']/ancestor::div[1]",  # XPath for OAuth One Click Setup
    "connect_account_button": "//button[span/span[text()='Connect Account']]",  # XPath for Connect Account button
    "email_or_phone_input": "//input[@id='identifierId']",  # XPath for Email or phone input
    "next_button": "//button[span[text()='Next']]",  # XPath for Next button after entering email
    "password_input_field": "//input[@name='Passwd']",  # XPath for password input field
    "next_button_after_password": "//button[span[text()='Next']]",  # XPath for Next button after entering password
    "continue_button": "//button[span[text()='Continue']]",  # XPath for Continue button
    "allow_button": "//button[span[text()='Allow']]"  # XPath for Allow button
}
