from flask import Flask, request, jsonify
from smartlead_automation import SmartLeadAutomation  # Import your existing class

app = Flask(__name__)

# Initialize the SmartLeadAutomation instance
@app.route('/add_account', methods=['POST'])
def add_account():
    data = request.json  # Get JSON data from the request
    login_email = data.get('login_email')  # Extract login_email from the request
    login_password = data.get('login_password')  # Extract login_password from the request
    auth_email = data.get('auth_email')  # Extract email from the request
    auth_password = data.get('auth_password')  # Extract password from the request

    try:
        # Initialize the automation object
        automation = SmartLeadAutomation(
            login_email=login_email,
            login_password=login_password,
            auth_email=auth_email,
            auth_password=auth_password
        )

        # Handle login and capture any error message
        status, message = automation.handle_login()
        if not status:
            return jsonify({"error": message}), 400  # Return error response if login fails
        
        # Proceed with the main automation process
        try:
            automation.main_process()
            message = automation.check_error_message()
            return jsonify({"message": message}), 200  # Return success response with the message
        except Exception as e:
            return jsonify({"error": f"Process failed: {str(e)}"}), 400
        finally:
            automation.close_driver()

    except Exception as e:
        return jsonify({"error": str(e)}), 400 


if __name__ == '__main__':
    app.run(host='0.0.0.0', port=8000)
